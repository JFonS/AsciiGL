#include "VAO.h"

VAO::VAO()
{
}
